module.exports.default = {
  mysql: {
    host: 'localhost',
    user: 'root',
    password: 'elforaneo',
    database: 'mapasdb'
  }
}
