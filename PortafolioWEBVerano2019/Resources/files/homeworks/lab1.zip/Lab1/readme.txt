Bajo la carpeta db está el script para la creación de la base de datos
por motivos de simpleza de pruebas se dejó sin contraseña.
